(function (l, z, C) {
  var t = (function () {
      var a,
        c = function () {
          return null != a
            ? a
            : (a = (function () {
                var a = [],
                  c = "unknown",
                  b = {trident: 0, gecko: 0, presto: 0, webkit: 0, unknown: -1},
                  d,
                  e = {},
                  c = document.createElement("nadu");
                for (d in c.style)
                  if ((c = (/^([A-Za-z][a-z]*)[A-Z]/.exec(d) || [])[1]))
                    (c = c.toLowerCase()), c in e ? e[c]++ : (e[c] = 1);
                for (var s in e) a.push([s, e[s]]);
                a = a
                  .sort(function (a, c) {
                    return c[1] - a[1];
                  })
                  .slice(0, 10);
                for (d = 0; d < a.length; d++)
                  switch (a[d][0]) {
                    case "moz":
                      b.gecko += 5;
                      break;
                    case "ms":
                      b.trident += 5;
                      break;
                    case "get":
                      b.webkit++;
                      break;
                    case "webkit":
                      b.webkit += 5;
                      break;
                    case "o":
                      b.presto += 2;
                      break;
                    case "xv":
                      b.presto += 2;
                  }
                "onhelp" in window && b.trident++;
                "maxConnectionsPerServer" in window && b.trident++;
                try {
                  void 0 !== window.ActiveXObject.toString && (b.trident += 5);
                } catch (l) {}
                void 0 !== function () {}.toSource && (b.gecko += 5);
                var a = "unknown",
                  q;
                for (q in b) b[q] > b[a] && (a = q);
                return a;
              })());
        },
        b = function () {
          return !!window.opera || (!!window.opr && !!window.opr.addons);
        },
        d = function () {
          return !!document.documentMode;
        },
        s = function () {
          return (
            !d() &&
            "undefined" !== typeof CSS &&
            CSS.supports("(-ms-ime-align:auto)")
          );
        },
        e = function () {
          return "webkit" == c();
        },
        l = function () {
          return (
            void 0 !== z.chrome &&
            "Opera Software ASA" != navigator.vendor &&
            void 0 === navigator.msLaunchUri &&
            e()
          );
        };
      return {
        isOpera: b,
        isIE: d,
        isEdge: s,
        isFirefox: function () {
          return "undefined" !== typeof InstallTrigger;
        },
        isWebkit: e,
        isChrome: l,
        isSafari: function () {
          return (
            !l() &&
            !s() &&
            !b() &&
            "WebkitAppearance" in document.documentElement.style
          );
        },
      };
    })(),
    r = function (a, c, b, d) {
      a.addEventListener
        ? a.addEventListener(c, b, d)
        : a.attachEvent && a.attachEvent("on" + c, b);
    },
    q = function (a, c, b, d) {
      document.removeEventListener
        ? a.removeEventListener(c, b, d || !1)
        : document.detachEvent && a.detachEvent("on" + c, b);
    },
    I = function (a) {
      var c;
      a = a.document;
      "undefined" !== typeof a.hidden
        ? (c = "visibilitychange")
        : "undefined" !== typeof a.mozHidden
        ? (c = "mozvisibilitychange")
        : "undefined" !== typeof a.msHidden
        ? (c = "msvisibilitychange")
        : "undefined" !== typeof a.webkitHidden &&
          (c = "webkitvisibilitychange");
      return c;
    },
    V = function (a, c) {
      var b = I(a),
        d = a.document;
      b && r(d, b, c, !1);
    },
    W = function (a) {
      var c = window.addEventListener ? "addEventListener" : "attachEvent";
      (0, window[c])(
        "attachEvent" == c ? "onmessage" : "message",
        function (c) {
          a(c[c.message ? "message" : "data"]);
        },
        !1
      );
    },
    J = function (a, c) {
      "function" === typeof a && Math.random() < c / 100 && a.call(this);
    },
    u = function (a) {
      try {
        for (
          var c = Array.prototype.slice.call(arguments, 1), b = 0;
          b < c.length;
          b++
        ) {
          if (!a) return !0;
          var d = a[c[b]];
          if (null === d || void 0 === d) return !0;
          a = d;
        }
        return !1;
      } catch (e) {
        return !0;
      }
    },
    A = function (a) {
      try {
        if (!a) return a;
        for (
          var c = Array.prototype.slice.call(arguments, 1), b, d = 0;
          d < c.length;
          d++
        ) {
          b = a[c[d]];
          if (!b) break;
          a = b;
        }
        return b;
      } catch (e) {
        return null;
      }
    },
    X = function (a, c) {
      try {
        if (!a) return !1;
        for (
          var b = Array.prototype.slice.call(arguments, 2), d = 0;
          d < b.length;
          d++
        ) {
          var e = a[b[d]];
          if (null === e || void 0 === e)
            return d === b.length - 1 ? typeof e === c : !1;
          a = e;
        }
        return typeof e === c;
      } catch (l) {
        return !1;
      }
    },
    K = function (a) {
      a &&
        document.body &&
        a.parentNode === document.body &&
        document.body.removeChild(a);
    },
    L = function (a, c, b) {
      var d = window.document.createElement("IFRAME");
      d.id = c;
      d.height = "5px";
      d.width = "5px";
      d.src = b ? b : "javascript:'1'";
      d.style.position = "absolute";
      d.style.top = "-10000px";
      d.style.left = "-10000px";
      d.style.visibility = "hidden";
      d.style.opacity = 0;
      window.document.body.appendChild(d);
      try {
        var l = d.contentDocument;
        if (
          l &&
          (l.open(),
          l.writeln(
            "<!DOCTYPE html><html><head><title></title></head><body></body></html>"
          ),
          l.close(),
          a)
        ) {
          var q = l.createElement("script");
          q &&
            ((q.type = "text/javascript"), (q.text = a), l.body.appendChild(q));
        }
      } catch (r) {
        e(r, "JS exception while injecting iframe");
      }
      return d;
    },
    e = function (a, c) {
      l.ueLogError(a, {
        logLevel: "ERROR",
        attribution: "A9TQForensics",
        message: c,
      });
    },
    Y = function (a, c, b) {
      a = {vfrd: 1 === c ? "8" : "4", dbg: a};
      "object" === typeof b
        ? (a.info = JSON.stringify(b))
        : "string" === typeof b && (a.info = b);
      return {server: window.location.hostname, fmp: a};
    };
  (function (a) {
    function c(a, c, b) {
      var d =
        "chrm msie ffox sfri opra phnt slnm othr extr xpcm invs poev njs cjs rhn clik1 rfs uam clik stln mua nfo hlpx clkh mmh chrm1 chrm2 wgl srvr zdim nomime chrm3 otch ivm.tst ivm.clk mmh2 clkh2 achf nopl spfp4 uam1 lsph nmim1 slnm2 crtt spfp misp spfp1 spfp2 clik2 clik3 spfp3 estr".split(
          " "
        );
      F = a < d.length ? d[a] : "othr";
      l.ue &&
        l.ue.event &&
        l.ue.event(Y(F, c, b), "a9_tq", "a9_tq.FraudMetrics.3");
    }
    function b() {
      var c = !1,
        g = "",
        b = 6,
        d = function (a, c) {
          var f,
            g,
            b = !1;
          for (f in a) b = b || -1 < c.indexOf(f);
          if ("function" === typeof Object.getOwnPropertyNames)
            for (f = Object.getOwnPropertyNames(a), g = 0; g < f.length; g++)
              b = b || -1 < c.indexOf(f[g]);
          if ("function" === typeof Object.keys)
            for (f = Object.keys(a), g = 0; g < f.length; g++)
              b = b || -1 < c.indexOf(f[g]);
          return b;
        },
        k = function (a) {
          try {
            return !!a.toString().match(/\{\s*\[native code\]\s*\}$/m);
          } catch (c) {
            return !1;
          }
        },
        m = 0;
      "undefined" !== typeof _evaluate &&
        -1 < _evaluate.toString().indexOf("browser.runScript") &&
        m++;
      "undefined" !== typeof ArrayBuffer &&
        "undefined" !== typeof print &&
        k(ArrayBuffer) &&
        !k(print) &&
        m++;
      "undefined" !== typeof ABORT_ERR && m++;
      try {
        "undefined" !== typeof browser &&
          "undefined" !== typeof browser._windowInScope &&
          "undefined" !== typeof browser._windowInScope._response &&
          m++;
      } catch (v) {}
      3 <= m && (c = !0);
      k = [
        function () {
          if (
            !0 ===
            d(
              C,
              "__webdriver_evaluate __selenium_evaluate __fxdriver_evaluate __driver_evaluate __webdriver_unwrapped __selenium_unwrapped __fxdriver_unwrapped __driver_unwrapped __webdriver_script_function __webdriver_script_func __webdriver_script_fn webdriver _Selenium_IDE_Recorder _selenium calledSelenium $cdc_asdjflasutopfhvcZLmcfl_ $chrome_asyncScriptInfo __$webdriverAsyncExecutor".split(
                " "
              )
            )
          )
            return !0;
          var c = function (c) {
              return (
                c.match(/\$[a-z]dc_/) && a.document[c] && a.document[c].cache_
              );
            },
            f;
          for (f in C) if (c(f)) return (g = f), !0;
          if ("function" === typeof Object.getOwnPropertyNames)
            for (
              var b = Object.getOwnPropertyNames(C), m = 0;
              m < b.length;
              m++
            )
              if (c(b[m])) return (g = f), !0;
          return !1;
        },
        function () {
          return d(
            a,
            "_phantom __nightmare _selenium callPhantom callSelenium _Selenium_IDE_Recorder webdriver __webdriverFunc domAutomation domAutomationController __lastWatirAlert __lastWatirConfirm __lastWatirPrompt _WEBDRIVER_ELEM_CACHE".split(
              " "
            )
          ) ||
            "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Promise ||
            "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Array ||
            "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Symbol
            ? !0
            : !1;
        },
        function () {
          return a.webdriver ||
            a.document.webdriver ||
            a.document.documentElement.hasAttribute("webdriver") ||
            a.document.documentElement.hasAttribute("selenium") ||
            a.document.documentElement.hasAttribute("driver") ||
            navigator.webdriver ||
            A(n, "navigator", "webdriver") ||
            "object" === typeof a.$cdc_asdjflasutopfhvcZLmcfl_ ||
            "object" === typeof a.document.$cdc_asdjflasutopfhvcZLmcfl_ ||
            (null != a.name && -1 < a.name.indexOf("driver"))
            ? ((g = null != a.name ? a.name : ""), !0)
            : !1;
        },
        function () {
          return a.external &&
            "function" === typeof a.external.toString &&
            a.external.toString() &&
            -1 != a.external.toString().indexOf("Sequentum")
            ? ((g = a.external.toString()), !0)
            : !1;
        },
        function () {
          for (var c in a) {
            var f;
            a: {
              if ((f = c) && 33 <= f.length && "function" === typeof a[f]) {
                var b = a[f];
                if (
                  /\.*_Array$/.test(f) ||
                  /\.*_Promise$/.test(f) ||
                  /\.*_Symbol$/.test(f) ||
                  (34 === f.length &&
                    "resolve" in b &&
                    "reject" in b &&
                    "prototype" in b) ||
                  (33 === f.length &&
                    "isConcatSpreadable" in b &&
                    "unscopables" in b &&
                    "toStringTag" in b &&
                    "match" in b)
                ) {
                  f = !0;
                  break a;
                }
              }
              f = !1;
            }
            if (f) return (g = c), !0;
          }
          return !1;
        },
        function () {
          var a = !1;
          if (!t.isFirefox()) return !1;
          var c;
          c = navigator.userAgent.match(/(firefox(?=\/))\/?\s*(\d+)/i) || [];
          c = 3 <= c.length ? c[2] : null;
          if (!c) return !1;
          60 <= c && void 0 === navigator.webdriver
            ? (a = !0)
            : 60 > c && "webdriver" in navigator && (a = !0);
          return a ? ((b = 43), (g = c.toString()), !0) : !1;
        },
      ];
      for (m = 0; m < k.length; m++)
        if (k[m].call()) {
          c = !0;
          break;
        }
      return {isSel: c, isTest: !1, info: g, headlessCode: b};
    }
    function d(a) {
      var g = new Date();
      !u(a, "Function", "prototype", "toString") &&
        X(g, "function", "toLocaleString") &&
        (a = a.Function.prototype.toString.call(g.toLocaleString)) &&
        100 < a.length &&
        0 <= a.indexOf("this.getTime") &&
        c(41);
    }
    function s() {
      var a =
          "AddChannel AddDesktopComponent AddFavorite AddSearchProvider AddService AddToFavoritesBar AutoCompleteSaveForm AutoScan bubbleEvent ContentDiscoveryReset ImportExportFavorites InPrivateFilteringEnabled IsSearchProviderInstalled IsServiceInstalled IsSubscribed msActiveXFilteringEnabled msAddSiteMode msAddTrackingProtectionList msClearTile msEnableTileNotificationQueue msEnableTileNotificationQueueForSquare150x150 msEnableTileNotificationQueueForSquare310x310 msEnableTileNotificationQueueForWide310x150 msIsSiteMode msIsSiteModeFirstRun msPinnedSiteState msProvisionNetworks msRemoveScheduledTileNotification msReportSafeUrl msScheduledTileNotification msSiteModeActivate msSiteModeAddButtonStyle msSiteModeAddJumpListItem msSiteModeAddThumbBarButton msSiteModeClearBadge msSiteModeClearIconOverlay msSiteModeClearJumpList msSiteModeCreateJumpList msSiteModeRefreshBadge msSiteModeSetIconOverlay msSiteModeShowButtonStyle msSiteModeShowJumpList msSiteModeShowThumbBar msSiteModeUpdateThumbBarButton msStartPeriodicBadgeUpdate msStartPeriodicTileUpdate msStartPeriodicTileUpdateBatch msStopPeriodicBadgeUpdate msStopPeriodicTileUpdate msTrackingProtectionEnabled NavigateAndFind raiseEvent setContextMenu ShowBrowserUI menuArguments onvisibilitychange scrollbar selectableContent version visibility mssitepinned AddUrlAuthentication CloseRegPopup FeatureEnabled GetJsonWebData GetRegValue Log LogShellErrorsOnly OpenPopup ReadFile RunGutsScript SaveRegInfo SetAppMaximizeTimeToRestart SetAppMinimizeTimeToRestart SetAutoStart SetAutoStartMinimized SetMaxMemory ShareEventFromBrowser ShowPopup ShowRadar WriteFile WriteRegValue summonWalrus".split(
            " "
          ),
        g = -1,
        b,
        d;
      "Microsoft Internet Explorer" === navigator.appName
        ? ((b = navigator.userAgent),
          (d = /MSIE ([0-9]{1,}[\.0-9]{0,})/),
          null !== d.exec(b) && (g = parseFloat(RegExp.$1)))
        : "Netscape" === navigator.appName &&
          ((b = navigator.userAgent),
          (d = /Trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/),
          null !== d.exec(b) && (g = parseFloat(RegExp.$1)));
      if (
        -1 === g &&
        null === navigator.userAgent.match(/Windows Phone/) &&
        window.external
      ) {
        for (b = g = 0; b < a.length; b++)
          if ("unknown" === typeof window.external[a[b]]) {
            g++;
            break;
          }
        0 < g && c(17);
      }
    }
    function z() {
      var f = a.navigator.userAgent;
      if (f && !/8.0 Safari|iPhone|iPad/.test(f)) {
        var b = {
            clearInterval: 42,
            clearTimeout: 41,
            eval: 33,
            alert: 34,
            prompt: 35,
            scroll: 35,
          },
          d = {
            clearInterval: 46,
            clearTimeout: 45,
            eval: 37,
            alert: 38,
            prompt: 39,
            scroll: 39,
          },
          e = 0;
        if (/Chrome/.test(f)) d = b;
        else if (((b = /Firefox/.test(f)), (f = /Safari/.test(f)), !b && !f))
          return;
        if (Function.prototype && Function.prototype.toString)
          for (var k in d)
            "function" === typeof window[k] &&
              (f = Function.prototype.toString.call(window[k])) &&
              f.length !== d[k] &&
              (e += 1);
        3 <= e && (6 <= e ? c(40, 0, e.toString()) : c(40, 1, e.toString()));
      }
    }
    function U() {
      var a = Math.random().toString(36).substr(2),
        b = null;
      W(function (d) {
        try {
          var e = d.split(" ");
          if (null !== b && e[0] === a && 0 < e[1].length) {
            var k = JSON.parse(e[1]);
            for (d = 0; d < k.length; d++)
              1 == d && "R29vZ2xlIFN3aWZ0U2hhZGVy" == k[d] && c(27);
          }
        } catch (m) {}
      });
      b = L(
        '(function fg45s() {                     var payload = [];                     var canvas = document.createElement("canvas");                     var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl") || canvas.getContext("moz-webgl");                     if (gl != null) {                         var debugInfo = gl.getExtension("WEBGL_debug_renderer_info");                         if (debugInfo != null) {                             payload.push(btoa(gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)));                             payload.push(btoa(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)));                             parent.postMessage(window.frameElement.id + " " + JSON.stringify(payload), parent.location.origin);                         }                     }                 }             )();',
        a
      );
      window.setTimeout(function () {
        try {
          b &&
            document.body &&
            b.parentNode === document.body &&
            document.body.removeChild(b),
            (b = null);
        } catch (a) {
          e(a, "JS exception while removing iframe");
        }
      }, 5e3);
    }
    function O() {
      function b() {
        q(a, "mousemove", d);
        q(a, "click", g);
      }
      function g() {
        try {
          c(23), b(), q(a.document, m, l);
        } catch (g) {
          e(g, "JS exception - detectClickDuringTabInactive");
        }
      }
      function d() {
        try {
          k || ((k = !0), c(24), b(), q(a.document, m, l));
        } catch (g) {
          e(g, "JS exception - detectMouseMovementsDuringTabInactive");
        }
      }
      function l() {
        try {
          var c;
          "undefined" !== typeof document.hidden
            ? (c = "hidden")
            : "undefined" !== typeof document.mozHidden
            ? (c = "mozHidden")
            : "undefined" !== typeof document.msHidden
            ? (c = "msHidden")
            : "undefined" !== typeof document.webkitHidden &&
              (c = "webkitHidden");
          (!0 !== document[c]) === !1
            ? (r(a, "mousemove", d, !1), r(a, "click", g, !1))
            : b();
        } catch (m) {
          e(m, "JS exception - handleVisibilityChangeDuringTabInactive");
        }
      }
      var k = !1,
        m = I(a);
      V(a, l);
    }
    var P = function () {
        var a = window.navigator,
          c = a.vendor,
          b = "undefined" !== typeof window.opr,
          d = -1 < a.userAgent.indexOf("Edg"),
          a = /Chrome/.test(a.userAgent);
        return /Google Inc\./.test(c) && a && !b && !d;
      },
      F = null,
      Q = function (a) {
        var b = [],
          d = new Date().getTime(),
          l = !1,
          k = !1,
          m,
          v,
          D = function () {
            q(a, "mousemove", p);
            q(a, "click", h);
          },
          p = function (a) {
            try {
              var f = new Date().getTime();
              if (!(100 > f - d)) {
                b.push({x: a.clientX, y: a.clientY});
                if (50 < b.length && (b.shift(), !(50 > b.length))) {
                  var m = b[0].x,
                    p = b[49].x,
                    h = b[0].y,
                    k = b[49].y;
                  a = k - h;
                  for (
                    var l = m - p,
                      m = h * p - m * k,
                      p = (a / l) * -1,
                      v = b[49].ts - b[0].ts,
                      h = !0,
                      k = 0;
                    k < b.length;
                    k++
                  )
                    if (0 != a * b[k].x + l * b[k].y + m) {
                      h = !1;
                      break;
                    }
                  !0 == h && ((v = {grdt: p, tmsp: v}), D(), c(19, 0, v));
                }
                d = f;
              }
            } catch (B) {
              e(B, "JS exception - recordHoverPosition");
            }
          },
          h = function (a) {
            try {
              var f = a.clientX,
                d = a.clientY,
                m = {hcc: b.length, cx: f, cy: d};
              if (0 === b.length) D(), c(18, 0, m);
              else if (null != f && null != d) {
                var p;
                m.hpos = b;
                var h = b[b.length - 1];
                p = Math.sqrt(Math.pow(f - h.x, 2) + Math.pow(d - h.y, 2));
                100 < p &&
                  ((m.hcc = b.length),
                  (m.cx = f),
                  (m.cy = d),
                  (m.dhp = p),
                  D(),
                  c(15, 0, m));
              }
            } catch (k) {
              e(k, "JS exception - checkClick");
            }
          },
          B = function (c) {
            try {
              (m = c.clientX), (v = c.clientY), (l = !0), q(a, "mouseup", B);
            } catch (b) {
              e(b, "JS exception - checkMouseUp");
            }
          },
          M = function () {
            try {
              (k = !0), q(a, "mousedown", M);
            } catch (c) {
              e(c, "JS exception - checkMouseDown");
            }
          },
          n = function (b) {
            try {
              l || k || c(49);
              var d = b.clientX - m,
                g = b.clientY - v;
              0 < d &&
                1 > d &&
                0 < g &&
                1 > g &&
                c(50, 0, {xDiff: d, yDiff: g});
              q(a, "click", n);
            } catch (p) {
              e(p, "JS exception - checkFirstClick");
            }
          };
        r(a, "mousemove", p, !1);
        r(a, "mouseup", B, !1);
        r(a, "mousedown", M, !1);
        r(a, "click", n, !1);
        r(a, "click", h, !1);
      },
      R = function () {
        if (t.isFirefox()) {
          var a = 0;
          void 0 !== window.onstorage && a++;
          var b = document.createElement("div");
          b.style.wordSpacing = "22%";
          "22%" === b.style.wordSpacing && a++;
          "function" === typeof b.getAttributeNames && a++;
          2 < a &&
            (void 0 === window.onabsolutedeviceorientation ||
              void 0 === navigator.permissions) &&
            c(37, 0, a);
        }
      },
      x = function () {
        return (
          null ===
          navigator.userAgent.match(/(iPad|iPhone|iPod|android|webOS)/i)
        );
      },
      G = function (a, b) {
        var d = a && a.navigator;
        !d ||
          !x() ||
          (d.mimeTypes && 0 != d.mimeTypes.length) ||
          (w ? c(b, 0, "chrm") : t.isFirefox() && c(b, 0, "ff"));
      },
      H = function (a) {
        J(function () {
          if (l.ue && l.ue.event) {
            var c = {vfrd: "0", info: JSON.stringify(a)};
            l.ue.event(
              {server: window.location.hostname, fmp: c},
              "a9_tq",
              "a9_tq.FraudMetrics.3"
            );
          }
        }, 10);
      },
      S = function () {
        var a = function (a, c) {
            for (var b, d = "", f = {}, g = {}, p = 0, h = 0; h < c.length; h++)
              g[c[h]] = String.fromCharCode(126 - h);
            var p = 0,
              e;
            for (e in a) -1 < c.indexOf(e) && ((f[e] = 1), p++);
            d = d + p + "!";
            if ("function" === typeof Object.getOwnPropertyNames) {
              b = Object.getOwnPropertyNames(a);
              for (h = p = 0; h < b.length; h++)
                -1 < c.indexOf(b[h]) && ((f[b[h]] = 1), p++);
              d = d + p + "!";
            }
            if ("function" === typeof Object.keys) {
              b = Object.keys(a);
              for (h = p = 0; h < b.length; h++)
                -1 < c.indexOf(b[h]) && ((f[b[h]] = 1), p++);
              d = d + p + "!";
            }
            if ("prototype" in Object && "hasOwnProperty" in Object.prototype)
              for (e in f)
                Object.prototype.hasOwnProperty.call(f, e) && (d += g[e]);
            else for (e in f) d += g[e];
            return encodeURIComponent(d);
          },
          c = document.createElement("nadu"),
          a = {
            w: a(
              window,
              "SVGFESpotLightElement XMLHttpRequestEventTarget onratechange StereoPannerNode dolphinInfo VTTCue globalStorage WebKitCSSRegionRule MozSmsFilter MediaController mozInnerScreenX onwebkitwillrevealleft DOMMatrix GeckoActiveXObject MediaQueryListEvent PhoneNumberService ServiceWorkerContainer yandex vc2hxtaq9c NavigatorDeviceStorage HTMLHtmlElement ScreenOrientation MSGesture mozCancelRequestAnimationFrame GetSVGDocument MediaSource webkitMediaStream DeviceMotionEvent webkitPostMessage doNotTrack WebKitMediaKeyError HTMLCollection InstallTrigger StorageObsolete CustomEvent orientation XMLHttpRequest Worker showModelessDialog EventSource onmouseleave SVGAnimatedPathData TouchList TextTrackCue onanimationend HTMLBodyElement fluid MSFrameUITab Generator SecurityPolicyViolationEvent ClientRectList SmartCardEvent CSSSupportsRule mmbrowser".split(
                " "
              )
            ),
            c: a(
              c.style,
              "XvPhonemes MozTextAlignLast webkitFilter MozPerspective msTextSizeAdjust OAnimationFillMode borderImageSource MozOSXFontSmoothing border-inline-start-color MozOsxFontSmoothing columns touchAction scroll-snap-coordinate webkitAnimationFillMode webkitLineSnap webkitGridAutoColumns animationDuration isolation overflowWrap offsetRotation webkitShapeOutside MozOpacity position justifySelf borderRight webkitMatchNearestMailBlockquoteColor msImeAlign parentRule MozColumnFill cssText borderRightStyle textOverflow webkitGridRow webkitBackgroundComposite length -moz-column-fill enableBackground flex-basis".split(
                " "
              )
            ),
          };
        l.ue &&
          l.ue.event &&
          ((a = {vfrd: "0", info: JSON.stringify(a)}),
          l.ue.event(
            {server: window.location.hostname, fmp: a},
            "a9_tq",
            "a9_tq.FraudMetrics.3"
          ));
      },
      T = function () {
        var b = function (a) {
            try {
              return "function" !== typeof a ||
                u(n, "Function", "prototype", "toString")
                ? null
                : n.Function.prototype.toString.call(a);
            } catch (c) {
              return null;
            }
          },
          d = function (a, c) {
            try {
              if ("function" !== typeof Object.getOwnPropertyDescriptor)
                return null;
              var d = Object.getPrototypeOf(a);
              if (!d) return null;
              var e = Object.getOwnPropertyDescriptor(d, c);
              return e ? b(e.get) : null;
            } catch (h) {
              return null;
            }
          },
          e = function (a) {
            var b = [28, 161, 141];
            !u(a, "getDetails", "a") &&
              "s" === a.getDetails.a &&
              0 <= b.indexOf(a.getDetails.l) &&
              c(45, 0, k);
          },
          l = function () {
            (function () {
              if ("function" === typeof Object.getOwnPropertyNames && x()) {
                var a = Object.getOwnPropertyNames(navigator);
                a && 1 < a.length && c(47, 0, a.length.toString());
              }
            })();
            0 < navigator.hardwareConcurrency &&
              !u(n, "navigator", "hardwareConcurrency") &&
              n.navigator.hardwareConcurrency !==
                navigator.hardwareConcurrency &&
              c(48, 0, n.navigator.hardwareConcurrency.toString());
            (function () {
              var b = [];
              if (!u(n, "navigator")) {
                n === a && (b.push("iwin"), c(51, 0, b));
                for (
                  var d =
                      "platform vendor maxTouchPoints userAgent deviceMemory webdriver hardwareConcurrency appVersion mimeTypes plugins languages".split(
                        " "
                      ),
                    f = 0;
                  f < d.length;
                  f++
                ) {
                  var e = d[f],
                    h;
                  if ("object" === typeof navigator[e]) {
                    h = navigator[e];
                    var g = n.navigator[e],
                      k = !1;
                    h || g
                      ? (h && g
                          ? h.length !== g.length
                            ? (k = !0)
                            : 0 < h.length &&
                              0 < g.length &&
                              "string" === typeof h[0] &&
                              h[0] !== g[0] &&
                              (k = !0)
                          : (k = !0),
                        (h = k))
                      : (h = !1);
                  } else
                    (h = navigator[e]),
                      (g = n.navigator[e]),
                      (h = h || g ? (h !== g ? !0 : !1) : !1);
                  h && b.push(e);
                }
                0 < b.length &&
                  (0 <= b.indexOf("webdriver") ? c(51, 0, b) : c(39, 1, b));
              }
            })();
          },
          k = (function (a) {
            if (!a) return null;
            for (var c = {}, e = 0, p = 0, h = 0; h < a.length; h++)
              for (var k = a[h].obj, l = a[h].props, q = 0; q < l.length; q++) {
                var n = l[q];
                c[n] = {};
                var r = A(k, l[q]);
                if (null === r || void 0 === r)
                  (p += 1), (c[n].a = "m"), (c[n].l = 0);
                else if ((r = "function" === typeof r ? b(r) : d(k, n)))
                  r && !/\[native code\]/.test(r)
                    ? ((c[n].a = "s"), (e += 1))
                    : (c[n].a = "p"),
                    (c[n].l = r.length);
              }
            return {sig: c, sCount: e, mCount: p};
          })([
            {
              obj: A(a, "chrome", "app"),
              props: ["getDetails", "getIsInstalled", "runningState"],
            },
            {obj: a.chrome, props: ["csi", "loadTimes", "runtime"]},
            {
              obj: navigator,
              props:
                "platform vendor userAgent mimeTypes plugins webdriver languages".split(
                  " "
                ),
            },
          ]);
        k &&
          (e(k.sig),
          w &&
            x() &&
            3 <= k.mCount &&
            (6 <= k.mCount ? c(46, 0, k) : c(46, 1, k)),
          l());
      },
      Z = function () {
        var b = a.Document && a.Document.prototype.evaluate;
        b &&
          (a.Document.prototype.evaluate = function () {
            try {
              var d = Error("test error"),
                l = d.stack && d.stack.toString();
              l && l.match(/(puppeteer|phantomjs|apply.xpath)/) && c(52, 0, l);
              a.Document.prototype.evaluate = b;
              return b.apply(this, arguments);
            } catch (n) {
              return (
                e(n, "JS exception while overidding evaluate"),
                (a.Document.prototype.evaluate = b),
                b.apply(this, arguments)
              );
            }
          });
      },
      $ = function () {
        var a = performance.now(),
          b = "function" === typeof document.hasTrustToken ? 1 : 0,
          c =
            -1 <
            ["www.amazon.com", "development.amazon.com"].indexOf(
              window.location.hostname
            )
              ? 1
              : 0,
          d = "function" === typeof AbortController ? 1 : 0,
          k = function (e) {
            e = {
              tt: 1,
              te: 0,
              et: (e - a).toFixed(3),
              cf: w ? 1 : 0,
              htt: b,
              sd: c,
              ac: d,
            };
            H(e);
          },
          l = function (a) {
            try {
              if (
                window.speechSynthesis &&
                a.message.includes("disabled") &&
                a.message.includes("Origin Trial")
              ) {
                var b = function () {
                  var b;
                  a: {
                    b = window.speechSynthesis.getVoices();
                    for (var c = 0; c < b.length; c++)
                      if (
                        null != b[c].name &&
                        b[c].name.toLowerCase().startsWith("google")
                      ) {
                        b = !1;
                        break a;
                      }
                    b = !0;
                  }
                  b
                    ? k(performance.now())
                    : e(
                        a,
                        "JS exception - trust token issuance handling is not chromium"
                      );
                };
                0 !== window.speechSynthesis.getVoices().length
                  ? b()
                  : window.speechSynthesis.addEventListener("voiceschanged", b);
              } else e(a, "JS exception - trust token issuance");
            } catch (c) {
              e(a, "JS exception - trust token fetch failure");
            }
          };
        if (w && b && c && d) {
          var n = new AbortController(),
            q = setTimeout(function () {
              try {
                n.abort();
              } catch (a) {
                e(a, "JS exception - Failure in TT set timeout");
              }
            }, 3e3);
          fetch("https://www.amazon.com/tt/i", {
            method: "GET",
            trustToken: {
              type: "token-request",
              issuer: "https://www.amazon.com",
            },
            signal: n.signal,
          })
            .then(function (b) {
              b = {
                tt: 1,
                te: 1,
                et: (performance.now() - a).toFixed(3),
                ht: b.status,
              };
              H(b);
            })
            ["catch"](function (a) {
              l(a);
            })
            ["finally"](function () {
              clearTimeout(q);
            });
        } else k(performance.now());
      };
    try {
      u(navigator, "userAgent") && c(20);
      var w = P(),
        y,
        n;
      (a.callPhantom ||
        a._phantom ||
        a.PhantomEmitter ||
        a.__phantomas ||
        /PhantomJS/.test(navigator.userAgent)) &&
        c(5);
      a.Buffer && c(12);
      a.emit && c(13);
      a.spawn && c(14);
      (null != a.domAutomation ||
        null != a.domAutomationController ||
        null != a._WEBDRIVER_ELEM_CACHE ||
        /HeadlessChrome/.test(navigator.userAgent) ||
        "" === navigator.languages) &&
        c(0);
      if (t.isChrome() && a.webkitRequestFileSystem)
        a.webkitRequestFileSystem(
          a.TEMPORARY,
          1,
          function () {},
          function () {
            c(0);
          }
        );
      else if (t.isSafari() && a.localStorage) {
        try {
          a.localStorage.setItem("__nadu", "");
        } catch (ba) {
          c(3);
        }
        a.localStorage.removeItem("__nadu");
      }
      G(a, 30);
      t.isWebkit() &&
        w &&
        x() &&
        (void 0 === a.chrome && c(0),
        a.chrome &&
          a.chrome.app &&
          !1 !== a.chrome.app.isInstalled &&
          void 0 !== navigator.languages &&
          c(31));
      a.external &&
        "function" === typeof a.external.toString &&
        a.external.toString() &&
        -1 < a.external.toString().indexOf("RuntimeObject") &&
        c(8);
      a.FirefoxInterfaces &&
        "function" === typeof a.FirefoxInterfaces &&
        a.FirefoxInterfaces("wdICoordinate", "wdIMouse", "wdIStatus") &&
        c(2);
      a.XPCOMUtils && c(9);
      ((a.Components &&
        ((a.Components.interfaces &&
          a.Components.interfaces.nsICommandProcessor) ||
          a.Components.wdICoordinate ||
          a.Components.wdIMouse ||
          a.Components.wdIStatus ||
          a.Components.classes)) ||
        (a.netscape &&
          a.netscape.security &&
          a.netscape.security.privilegemanager)) &&
        c(8);
      a.isExternalUrlSafeForNavigation && c(1);
      !a.opera ||
        null === a.opera._browserjsran ||
        (0 !== a.opera._browserjsran && !1 !== a.opera._browserjsran) ||
        c(4);
      a.screen &&
        (1 >= a.screen.availHeight ||
          1 >= a.screen.availWidth ||
          1 >= a.screen.height ||
          1 >= a.screen.width ||
          0 >= a.screen.devicePixelRatio) &&
        c(10);
      var E = window.setInterval(function () {
        try {
          var a = b();
          a.isSel &&
            (c(a.headlessCode, !0 === a.isTest ? 1 : 0, a.info),
            window.clearInterval(E),
            K(y));
        } catch (d) {
          window.clearInterval(E), e(d, "JS exception - detectSelenium");
        }
      }, 1e3);
      window.setTimeout(function () {
        try {
          window.clearInterval(E), K(y);
        } catch (a) {
          e(a, "JS exception - clearInterval for detectSelenium");
        }
      }, 1e4);
      var N = a.PointerEvent;
      a.PointerEvent = function () {
        c(11);
        if (void 0 !== N) {
          var a = Array.prototype.slice.call(arguments);
          return new N(a);
        }
        return null;
      };
      s();
      Q(a);
      O();
      U();
      (0 !== a.outerHeight && 0 !== a.outerWidth) || c(29);
      R();
      !x() ||
        (navigator.plugins && 0 != navigator.plugins.length) ||
        (w ? c(38, 0, "chrm") : t.isFirefox() && c(38, 0, "ff"));
      J(S, 10);
      w && x() && a.chrome && !a.chrome.csi && !a.chrome.loadTimes && c(25);
      z();
      y = L(null, Math.random().toString(36).substr(2));
      n = u(y, "contentWindow") ? a : y.contentWindow;
      d(n);
      G(n, 42);
      0 === A(navigator, "connection", "rtt") && c(44);
      T();
      Z();
      $();
    } catch (aa) {
      e(aa, "JS exception - ");
    }
  })(z);
})(ue_csm, window, document);
